# Multi-AC DCT-QIM Lab

Complete the TODO functions in `embed_multi_ac_qim.py`, then run:

```bash
./embed_multi_ac_qim.py frame.png stego.png
./extract_multi_ac_qim.py stego.png extracted_message.txt
./compare_file.py expected_message.txt extracted_message.txt
cat metrics.json
```


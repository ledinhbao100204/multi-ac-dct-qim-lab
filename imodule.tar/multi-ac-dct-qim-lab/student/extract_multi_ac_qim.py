#!/usr/bin/env python3
import sys
from pathlib import Path

import cv2
import numpy as np


MESSAGE_LENGTH = 5
DELTA = 18
AC_COEFFICIENTS = [(2, 3), (3, 2), (4, 1)]


def bits_to_message(bits: str) -> str:
    chars = []
    for start in range(0, len(bits), 8):
        byte = bits[start : start + 8]
        chars.append(chr(int(byte, 2)))
    return "".join(chars)


def block_slices(height: int, width: int):
    usable_height = height - (height % 8)
    usable_width = width - (width % 8)
    for row in range(0, usable_height, 8):
        for col in range(0, usable_width, 8):
            yield row, col


def main() -> None:
    in_path = Path(sys.argv[1] if len(sys.argv) > 1 else "stego.png")
    out_path = Path(sys.argv[2] if len(sys.argv) > 2 else "extracted_message.txt")

    image = cv2.imread(str(in_path), cv2.IMREAD_COLOR)
    if image is None:
        raise SystemExit(f"cannot open {in_path}")

    height, width = image.shape[:2]
    bit_count = MESSAGE_LENGTH * 8
    bits = []

    ycrcb = cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb)
    y_channel = ycrcb[:, :, 0].astype(np.float32)

    for row, col in block_slices(height, width):
        if len(bits) >= bit_count:
            break

        block = y_channel[row : row + 8, col : col + 8]
        dct_block = cv2.dct(block - 128.0)

        for coeff_y, coeff_x in AC_COEFFICIENTS:
            if len(bits) >= bit_count:
                break
            q = int(np.round(float(dct_block[coeff_y, coeff_x]) / DELTA))
            bits.append(str(q % 2))

    if len(bits) != bit_count:
        raise SystemExit(f"extracted {len(bits)} bits but expected {bit_count}")

    message = bits_to_message("".join(bits))
    out_path.write_text(message, encoding="ascii")
    print(f"extracted message: {message}")


if __name__ == "__main__":
    main()


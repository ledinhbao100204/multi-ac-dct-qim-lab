#!/usr/bin/env python3
import json
import math
import sys
from pathlib import Path

import cv2
import numpy as np


MESSAGE = "HELLO"
DELTA = 18
AC_COEFFICIENTS = [(2, 3), (3, 2), (4, 1)]


def message_to_bits(message: str) -> str:
    # TODO: Convert each ASCII character to 8 bits.
    # Example: "H" -> "01001000"
    raise NotImplementedError("complete message_to_bits()")


def embed_bit(coefficient: float, bit: int, delta: int) -> float:
    # TODO: Implement QIM parity embedding.
    # Quantize coefficient/delta, force q % 2 == bit, then return q * delta.
    raise NotImplementedError("complete embed_bit()")


def psnr(original: np.ndarray, stego: np.ndarray) -> float:
    mse = np.mean((original.astype(np.float32) - stego.astype(np.float32)) ** 2)
    if mse == 0:
        return float("inf")
    return 20.0 * math.log10(255.0 / math.sqrt(float(mse)))


def block_slices(height: int, width: int):
    usable_height = height - (height % 8)
    usable_width = width - (width % 8)
    for row in range(0, usable_height, 8):
        for col in range(0, usable_width, 8):
            yield row, col


def main() -> None:
    in_path = Path(sys.argv[1] if len(sys.argv) > 1 else "frame.png")
    out_path = Path(sys.argv[2] if len(sys.argv) > 2 else "stego.png")

    image = cv2.imread(str(in_path), cv2.IMREAD_COLOR)
    if image is None:
        raise SystemExit(f"cannot open {in_path}")

    bits = message_to_bits(MESSAGE)
    if not bits or any(bit not in "01" for bit in bits):
        raise SystemExit("message_to_bits() must return a string containing only 0 and 1")

    height, width = image.shape[:2]
    capacity = (height // 8) * (width // 8) * len(AC_COEFFICIENTS)
    if len(bits) > capacity:
        raise SystemExit(f"payload too large: bits={len(bits)} capacity={capacity}")

    ycrcb = cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb)
    y_channel = ycrcb[:, :, 0].astype(np.float32)

    bit_index = 0
    for row, col in block_slices(height, width):
        if bit_index >= len(bits):
            break

        block = y_channel[row : row + 8, col : col + 8]
        dct_block = cv2.dct(block - 128.0)

        for coeff_y, coeff_x in AC_COEFFICIENTS:
            if bit_index >= len(bits):
                break
            bit = int(bits[bit_index])
            dct_block[coeff_y, coeff_x] = embed_bit(float(dct_block[coeff_y, coeff_x]), bit, DELTA)
            bit_index += 1

        y_channel[row : row + 8, col : col + 8] = cv2.idct(dct_block) + 128.0

    ycrcb[:, :, 0] = np.clip(y_channel, 0, 255).astype(np.uint8)
    stego = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)

    if not cv2.imwrite(str(out_path), stego):
        raise SystemExit(f"cannot write {out_path}")

    metric = {
        "message": MESSAGE,
        "bit_count": len(bits),
        "delta": DELTA,
        "ac_coefficients": AC_COEFFICIENTS,
        "psnr": psnr(image, stego),
    }
    Path("metrics.json").write_text(json.dumps(metric, indent=2) + "\n", encoding="ascii")

    print(
        "multi-ac dct-qim embedded: "
        f"message={MESSAGE} bits={len(bits)} coefficients_per_block={len(AC_COEFFICIENTS)} "
        f"delta={DELTA} output={out_path} psnr={metric['psnr']:.2f} dB"
    )


if __name__ == "__main__":
    main()


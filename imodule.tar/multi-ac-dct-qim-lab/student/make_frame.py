#!/usr/bin/env python3
from pathlib import Path

import cv2
import numpy as np


def main() -> None:
    height, width = 256, 256
    y = np.linspace(0, 1, height, dtype=np.float32)[:, None]
    x = np.linspace(0, 1, width, dtype=np.float32)[None, :]

    blue = 90 + 70 * x + 25 * np.sin(2 * np.pi * y * 4)
    green = 70 + 120 * y + 20 * np.cos(2 * np.pi * x * 3)
    red = 80 + 80 * (1 - x) + 50 * np.sin(2 * np.pi * (x + y))

    image = np.stack([blue, green, red], axis=2)
    for row in range(32, 224, 48):
        cv2.rectangle(image, (24, row), (232, row + 18), (180, 120, 70), -1)
    cv2.circle(image, (178, 78), 36, (70, 170, 210), -1)
    cv2.putText(image, "DCT", (72, 150), cv2.FONT_HERSHEY_SIMPLEX, 1.4, (245, 245, 245), 3, cv2.LINE_AA)

    out = np.clip(image, 0, 255).astype(np.uint8)
    if not cv2.imwrite("frame.png", out):
        raise SystemExit("cannot write frame.png")
    print(f"created {Path('frame.png').resolve()}")


if __name__ == "__main__":
    main()


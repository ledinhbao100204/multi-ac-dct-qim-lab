#!/usr/bin/env python3
import sys
from pathlib import Path


def main() -> None:
    expected_path = Path(sys.argv[1] if len(sys.argv) > 1 else "expected_message.txt")
    actual_path = Path(sys.argv[2] if len(sys.argv) > 2 else "extracted_message.txt")

    expected = expected_path.read_text(encoding="ascii").strip()
    actual = actual_path.read_text(encoding="ascii").strip()

    if expected != actual:
        raise SystemExit(f"messages differ: expected={expected!r} actual={actual!r}")

    print("messages match")


if __name__ == "__main__":
    main()


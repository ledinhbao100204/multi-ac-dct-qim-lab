$ErrorActionPreference = "Stop"

$lab = "multi-ac-dct-qim-lab"
$registry = "ledinhbao1002"

docker tag "$lab.student.student" "$registry/$lab.student.student"
docker push "$registry/$lab.student.student"


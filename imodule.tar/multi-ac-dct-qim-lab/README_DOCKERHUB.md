# Docker Hub image

This lab is configured to use the Docker Hub namespace `ledinhbao1002`.

When Labtainers starts `multi-ac-dct-qim-lab`, it resolves the student
container image as:

```text
ledinhbao1002/multi-ac-dct-qim-lab.student.student:latest
```

The relevant settings are in `config/start.config`:

```text
REGISTRY ledinhbao1002
BASE_REGISTRY labtainers
```

If an older local image is cached, remove the lab first so Labtainers fetches
the current image from Docker Hub:

```bash
removelab.py multi-ac-dct-qim-lab
labtainer multi-ac-dct-qim-lab
```

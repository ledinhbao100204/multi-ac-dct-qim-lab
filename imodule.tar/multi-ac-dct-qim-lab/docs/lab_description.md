# Lab: Giấu tin bằng nhiều hệ số AC trên block DCT

## Mục tiêu

Trong bài lab này, sinh viên cài đặt một kỹ thuật giấu tin đơn giản trên ảnh số bằng biến đổi DCT theo block 8x8. Thông điệp ASCII được chuyển thành chuỗi bit, sau đó từng bit được nhúng vào nhiều hệ số AC trung tần trong cùng một block DCT bằng phương pháp QIM (Quantization Index Modulation).

Sau khi hoàn thành, sinh viên có thể:

- chuyển thông điệp ASCII thành chuỗi bit 8-bit cho từng ký tự;
- chia ảnh thành các block 8x8;
- biến đổi từng block sang miền DCT;
- chọn nhiều hệ số AC trung tần để tăng số bit nhúng trên mỗi block;
- nhúng bit vào hệ số DCT bằng quy tắc chẵn/lẻ của chỉ số lượng tử;
- phục hồi ảnh stego bằng IDCT;
- trích xuất lại thông điệp từ ảnh stego;
- so sánh ảnh gốc và ảnh stego bằng chỉ số PSNR.

## Mô hình bài lab

Bài lab có một container `student`. Trong container này đã có Python, OpenCV, NumPy, SciPy và các file cần thiết để chạy thí nghiệm.

Các file chính trong thư mục `student`:

- `frame.png`: ảnh gốc dùng để nhúng thông điệp.
- `embed_multi_ac_qim.py`: chương trình nhúng tin. Sinh viên cần hoàn thiện các hàm TODO trong file này.
- `extract_multi_ac_qim.py`: chương trình trích xuất thông điệp từ ảnh stego.
- `compare_file.py`: chương trình so sánh thông điệp trích xuất với kết quả mong đợi.
- `expected_message.txt`: thông điệp đúng để kiểm tra.
- `secret_message.txt`: thông điệp bí mật trong bài lab.
- `README.md`: tóm tắt các lệnh chạy nhanh.

Thông điệp mặc định của bài lab là:

```text
HELLO
```

## Ý tưởng kỹ thuật

Ảnh đầu vào được đọc ở dạng BGR, sau đó chuyển sang không gian màu YCrCb. Bài lab chỉ nhúng tin trên kênh độ sáng `Y` để giữ thay đổi tập trung vào thành phần thị giác quan trọng nhất.

Kênh `Y` được chia thành các block 8x8. Với mỗi block:

1. Trừ giá trị 128 để đưa dữ liệu pixel về quanh 0.
2. Tính DCT 2D bằng `cv2.dct`.
3. Nhúng bit vào một số hệ số AC đã chọn.
4. Tính IDCT bằng `cv2.idct`.
5. Cộng lại 128, cắt giá trị về khoảng `[0, 255]`, rồi ghép lại thành ảnh stego.

Các hệ số AC được dùng trong bài lab:

```python
AC_COEFFICIENTS = [(2, 3), (3, 2), (4, 1)]
```

Mỗi block có thể chứa tối đa 3 bit vì có 3 hệ số AC được dùng. Với ảnh `frame.png` kích thước 256x256, số block 8x8 là:

```text
(256 / 8) * (256 / 8) = 32 * 32 = 1024 block
```

Dung lượng nhúng tối đa là:

```text
1024 * 3 = 3072 bit
```

Thông điệp `HELLO` có 5 ký tự ASCII, tương đương:

```text
5 * 8 = 40 bit
```

Vì vậy ảnh có đủ dung lượng để nhúng thông điệp.

## QIM parity embedding

Trong file `embed_multi_ac_qim.py`, hằng số lượng tử là:

```python
DELTA = 18
```

Để nhúng một bit vào hệ số DCT, hệ số được lượng tử hóa theo `DELTA`:

```text
q = round(coefficient / DELTA)
```

Sau đó điều chỉnh `q` sao cho:

- nếu bit cần nhúng là `0`, `q` phải là số chẵn;
- nếu bit cần nhúng là `1`, `q` phải là số lẻ.

Hệ số DCT mới được tính lại bằng:

```text
coefficient' = q * DELTA
```

Khi trích xuất, chương trình đọc lại cùng vị trí hệ số AC, tính lại:

```text
q = round(coefficient' / DELTA)
bit = q % 2
```

Vì bộ nhúng và bộ trích xuất dùng cùng `DELTA` và cùng danh sách hệ số AC, thông điệp có thể được khôi phục từ ảnh stego.

## Nhiệm vụ của sinh viên

Mở file:

```text
student/embed_multi_ac_qim.py
```

Hoàn thiện hai hàm sau.

### 1. `message_to_bits(message: str) -> str`

Hàm này nhận vào một chuỗi ASCII và trả về chuỗi bit.

Yêu cầu:

- mỗi ký tự được mã hóa thành đúng 8 bit;
- kết quả chỉ chứa ký tự `0` và `1`;
- ví dụ ký tự `H` có mã ASCII 72, biểu diễn nhị phân 8 bit là `01001000`.

Gợi ý:

```python
format(ord(ch), "08b")
```

### 2. `embed_bit(coefficient: float, bit: int, delta: int) -> float`

Hàm này nhận một hệ số DCT, bit cần nhúng và khoảng lượng tử `delta`, sau đó trả về hệ số mới.

Yêu cầu:

- tính `q = round(coefficient / delta)`;
- nếu `q % 2` chưa bằng bit cần nhúng thì điều chỉnh `q`;
- trả về `q * delta`.

Sinh viên nên điều chỉnh `q` theo hướng làm thay đổi hệ số ít nhất có thể.

## Cách chạy bài lab

Trong thư mục `student`, chạy lần lượt:

```bash
./embed_multi_ac_qim.py frame.png stego.png
./extract_multi_ac_qim.py stego.png extracted_message.txt
./compare_file.py expected_message.txt extracted_message.txt
cat metrics.json
```

Nếu chương trình nhúng chạy đúng, màn hình sẽ có dòng tương tự:

```text
multi-ac dct-qim embedded: message=HELLO ...
```

Nếu chương trình trích xuất chạy đúng:

```text
extracted message: HELLO
```

Nếu thông điệp trích xuất khớp với file mong đợi:

```text
messages match
```

File `metrics.json` phải được tạo và có trường `psnr`, ví dụ:

```json
{
  "message": "HELLO",
  "bit_count": 40,
  "delta": 18,
  "ac_coefficients": [[2, 3], [3, 2], [4, 1]],
  "psnr": 42.0
}
```

Giá trị PSNR càng cao thì ảnh stego càng giống ảnh gốc. Trong bài lab này, PSNR được dùng để quan sát mức biến dạng sau khi nhúng tin.

## Tiêu chí hoàn thành

Bài lab được xem là hoàn thành khi:

- `embed_multi_ac_qim.py` chạy thành công và tạo được `stego.png`;
- `extract_multi_ac_qim.py` trích xuất được thông điệp `HELLO`;
- `compare_file.py` báo `messages match`;
- file `metrics.json` tồn tại và chứa trường `"psnr"`;
- các kiểm tra tự động của Labtainers đều đạt.


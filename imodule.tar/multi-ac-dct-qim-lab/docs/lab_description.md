# Lab: Giau tin bang nhieu he so AC tren block DCT

## Muc tieu

Sinh vien giau nhieu bit tren nhieu he so AC trong cung mot block DCT 8x8.

- chuyen thong diep ASCII thanh chuoi bit;
- chia anh thanh cac block 8x8;
- tinh DCT cho tung block anh;
- chon nhieu he so AC trung tan;
- nhung bit vao cac he so AC bang QIM voi khoang `Delta`;
- thuc hien IDCT de khoi phuc block anh;
- ghep cac block thanh anh stego;
- so sanh anh goc va anh stego.

## Mo hinh lab

Lab gom mot container:

- `student`: co Python, OpenCV, NumPy, SciPy va cac file bai lab.

File dau vao:

- `frame.png`: anh goc.
- thong diep mac dinh: `HELLO`.

## Cong thuc DCT 2D

Voi block 8x8, bien doi DCT co dang:

```text
F(u,v) = sum_x=0..7 sum_y=0..7 C(u)C(v)f(x,y)
         cos((2x+1)u*pi/16) cos((2y+1)v*pi/16)
```

Trong do `C(0)=1/sqrt(8)` va `C(k)=1/2` voi `k>0` theo quy uoc truc giao thuong dung. OpenCV `cv2.dct()` cai dat DCT truc giao tuong thich cho thuc hanh nay.

## Nhiem vu

1. Mo file `embed_multi_ac_qim.py`.

2. Hoan thien ham `message_to_bits(message)`.

   Ham phai chuyen moi ky tu ASCII thanh 8 bit, vi du:

   ```text
   H -> 01001000
   ```

   def message_to_bits(message: str) -> str:
    bits = ""
    for ch in message:
        bits += format(ord(ch), "08b")
    return bits

3. Hoan thien ham `embed_bit(coefficient, bit, delta)`.

   Dung QIM parity:

   - tinh `q = round(coefficient / delta)`;
   - neu `q % 2` khac bit can nhung, chon `q-1` hoac `q+1` sao cho he so moi gan he so cu hon;
   - tra ve `q * delta`.

4. Chay chuong trinh nhung:

   ```bash
   ./embed_multi_ac_qim.py frame.png stego.png
   ```

   Neu lam dung, man hinh co dong:

   ```text
   multi-ac dct-qim embedded
   ```

5. Trich xuat thong diep tu anh stego:

   ```bash
   ./extract_multi_ac_qim.py stego.png extracted_message.txt
   ```

   Neu lam dung, man hinh co dong:

   ```text
   extracted message: HELLO
   ```

6. So sanh thong diep:

   ```bash
   ./compare_file.py expected_message.txt extracted_message.txt
   ```

7. Xem chi so PSNR:

   ```bash
   cat metrics.json
   ```

## Goi y

Trong moi block 8x8, bai lab nhung toi da 3 bit vao 3 he so AC:

```python
AC_COEFFICIENTS = [(2, 3), (3, 2), (4, 1)]
```

Voi thong diep `HELLO`, payload co `5 * 8 = 40` bit. Vi moi block chua 3 bit, chuong trinh can it nhat 14 block anh.


## Cham diem tu dong

He thong cham diem kiem tra:

- `student:embed_multi_ac_qim.py.stdout` co chuoi `multi-ac dct-qim embedded`;
- `student:extract_multi_ac_qim.py.stdout` co chuoi `extracted message: HELLO`;
- `student:compare_file.py.stdout` co chuoi `messages match`;
- `student:metrics.json` co chuoi `"psnr"`;
- marker pregrade `student:.local/result/message_compare.txt` co chuoi `messages match`.


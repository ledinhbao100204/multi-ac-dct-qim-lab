# Instructor Solution Notes

Do not copy this file into the student home archive unless you want to publish the solution.

`message_to_bits()`:

```python
return "".join(f"{ord(char):08b}" for char in message)
```

`embed_bit()`:

```python
q = int(np.round(coefficient / delta))
if q % 2 != bit:
    up = q + 1
    down = q - 1
    if abs(up * delta - coefficient) <= abs(down * delta - coefficient):
        q = up
    else:
        q = down
return float(q * delta)
```

Expected command sequence:

```bash
./embed_multi_ac_qim.py frame.png stego.png
./extract_multi_ac_qim.py stego.png extracted_message.txt
./compare_file.py expected_message.txt extracted_message.txt
cat metrics.json
```

Expected output includes:

```text
multi-ac dct-qim embedded
extracted message: HELLO
messages match
```

